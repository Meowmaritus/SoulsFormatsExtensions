﻿using SoulsFormats;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoulsFormatsExtensions
{
    public partial class FXR1
    {
        public class Ast
        {
            public static int GetSize(bool isLong)
                => (isLong ? 24 : 12) + 16;

            public void Read(BinaryReaderEx br, FxrEnvironment env)
            {
                throw new NotImplementedException();
            }
        }
    }
}
