﻿using SoulsFormats;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoulsFormatsExtensions
{
    public partial class FXR1
    {
        public class FlowAction
        {
            public int ActionType;
            public Ast Ast;

            public static int GetSize(bool isLong)
                => (isLong ? 8 : 4) + Ast.GetSize(isLong);

            public static FlowAction Read(BinaryReaderEx br, FxrEnvironment env)
            {
                var action = new FlowAction();
                action.ActionType = br.ReadFXR1Varint();
                action.Ast = env.GetAst(br.Position);
                br.Position += Ast.GetSize(br.VarintLong);

                return action;
            }
        }
    }
}
