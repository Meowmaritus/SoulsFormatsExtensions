﻿using SoulsFormats;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoulsFormatsExtensions
{
    public partial class FXR1
    {
        public class AstPool2
        {
            public int SubType;
            public Ast ParentAst;

            public class AstPool2Type27 : AstPool2
            {
                public float Unk1;
                public float Unk2;
                public float Unk3;
                public float Unk4;
                public int TextureID;
                public int Unk6;
                public AstPool2Field[] Unk7;
                public int Unk8;
                public int Unk9;
                public int Unk10;
                public float Unk11;
                public AstPool2Field[] DS1R_Unk5;
                public float DS1R_Unk6;
                public int DS1R_Unk7;
                public int DS1R_Unk8;
                public int DS1R_Unk9;
                public int DS1R_Unk10;
                public int DS1R_Unk11;
                public AstPool2Type27(BinaryReaderEx br, FxrEnvironment env)
                {
                    Unk1 = br.ReadSingle();
                    Unk2 = br.ReadSingle();
                    Unk3 = br.ReadSingle();
                    br.AssertInt32(0);
                    Unk4 = br.ReadSingle();
                    if (br.VarintLong)
                        br.AssertInt32(0);
                    TextureID = br.ReadInt32();
                    Unk6 = br.ReadInt32();
                    br.AssertInt32(0);
                    Unk7 = AstPool2Field.ReadMany(br, env, 10);
                    Unk8 = br.ReadInt32();
                    Unk9 = br.ReadInt32();
                    Unk10 = br.ReadInt32();
                    Unk11 = br.ReadSingle();
                    if (br.VarintLong)
                    {
                        DS1R_Unk5 = AstPool2Field.ReadMany(br, env, 5);
                        DS1R_Unk6 = br.ReadInt32();
                        DS1R_Unk7 = br.ReadInt32();
                        DS1R_Unk8 = br.ReadInt32();
                        DS1R_Unk9 = br.ReadInt32();
                        DS1R_Unk10 = br.ReadInt32();
                        DS1R_Unk11 = br.ReadInt32();
                    }
                }
            }

            public class AstPool2Type28 : AstPool2
            {
                public AstPool2Field[] Unk1;
                public int Unk2;

                public AstPool2Type28(BinaryReaderEx br, FxrEnvironment env)
                {
                    Unk1 = AstPool2Field.ReadMany(br, env, 3);
                    Unk2 = br.ReadInt32();
                }
            }

            public static AstPool2 Read(BinaryReaderEx br, FxrEnvironment env)
            {
                long startOffset = br.Position;

                int subType = br.ReadInt32();
                int size = br.ReadInt32();
                long preDataCount = br.ReadFXR1Varint();
                long offsetToPreDataNumbers = br.ReadFXR1Varint();
                long offsetToPreDataSubtypes = br.ReadFXR1Varint();
                long offsetToParentAst = br.ReadFXR1Varint();

                var parentAst = env.GetAst(offsetToParentAst);

                AstPool2 data;

                switch (subType)
                {
                    case 27: data = new AstPool2Type27(br, env); break;
                    default: throw new NotImplementedException();
                }

                data.ParentAst = parentAst;

                //pre data nubmers go here during write

                //pre data subtypes go here during write

                //the packed shit from switch(subType) all goes here during write?

                br.Position = startOffset + size;

                return data;
            }
        }
    }
}
