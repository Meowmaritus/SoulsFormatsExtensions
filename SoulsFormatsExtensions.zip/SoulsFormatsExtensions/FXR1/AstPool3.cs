﻿using SoulsFormats;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoulsFormatsExtensions
{
    public partial class FXR1
    {
        public class AstPool3
        {


            public void Read(BinaryReaderEx br, FxrEnvironment env)
            {

            }
        }
    }
}
