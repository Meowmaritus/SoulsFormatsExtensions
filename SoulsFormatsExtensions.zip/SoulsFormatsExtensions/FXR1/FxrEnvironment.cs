﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SoulsFormatsExtensions
{
    public class FxrEnvironment
    {
        public FXR1.AstPool1 GetAstPool1(long offset)
        {
            throw new NotImplementedException();
        }

        public FXR1.Function GetFunction(long offset)
        {
            throw new NotImplementedException();
        }

        public FXR1.Ast GetAst(long offset)
        {
            throw new NotImplementedException();
        }

        public FXR1.FlowNode GetFlowNode(long offset)
        {
            throw new NotImplementedException();
        }

        public FXR1.FlowEdge GetFlowEdge(long offset)
        {
            throw new NotImplementedException();
        }

        public FXR1.FlowAction GetFlowAction(long offset)
        {
            throw new NotImplementedException();
        }

    }
}
