﻿namespace SoulsFormats
{
    interface IMsbEntry
    {
        string Name { get; set; }
    }
}
